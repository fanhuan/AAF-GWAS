---
layout: post
title:  Summer Field Season - 2012
categories: [Field work]
tags: [Field work]
---
How time flies! I cannot believe that the fall semester is here! When I look back, I cannot believe that I survived my first field summer in US, thanks to Marian Lea and Amelia Krug! A lot of challenges but also gave me an excellent opportunity to experient local Wisconsin culture and to see the awesome landscapes of Midwest.

Here are some unforgettable things in this summer:
<ol>
	<li>Driving and transportation. I need to say that it is fun to drive on country road with a paper Altas. Marian is so good at this!</li>
	<li>Ticks. At the beginning, you hate them, then you used to them, after summer, you will kind of miss them. But probably not for Marian, she got the Lyme disease this summer...</li>
	<li>Hot wave. People who deny global warning and global climate change definitely will change their mind after this summer. Although I come from subtropical area, some days in this summer is really hot, even for me. However, it is also an unforgettable experience that working in forest under over 100 F for one week, WITH long shirts and hat to avoid annoying mosquito and flyers.</li>
	<li>The sun light through the canopy. I cannot describe how beautiful and peaceful it is! When sit on the forest floor to have a break, look at the sunshine, makes me happy and grateful for the nature.</li>
	<li>Food. I guess I had the most American food this summer in my whole life. But they are good! For me, the problem is that I am so ignorance about American food that I do not know what to order when I get into the restaurant. I do not know what is cheese curbs, french fry, etc. It is funny just to order foods according to their name without knowing what the earth they are.</li>
	<li>Camping. This is the first time I camping outdoor. In China, we rarely do this. But I like it, especially camping near the lake or river shores. Even better with raining. I know this is kind of weird, but I like to listen the raining music.</li>
</ol>