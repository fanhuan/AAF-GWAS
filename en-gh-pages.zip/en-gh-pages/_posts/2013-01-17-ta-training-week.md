---
layout: post
title:  TA training week
categories: [Teaching]
tags: [Teaching]
---


Well, almost half of this week was dedicated for the TA training of Bot152, a HUGH class in campus, if not the biggest. I do learn a lot from this training, learned a lot of things which I have never think about.

![Domino effect](http://i.imgur.com/jD30ULN.gif)

I did not know which section I am going to teach untill this afternoon. I was shocked by what I got: TA for discussion! You know what? My first thought was like this: I always get what I am afraid of. What a challenge for me! If I get a lab section, that is fine for me, since Iprobably do not need to talk too much in the class. But as a discussion TA, this is unavoidable. However, I do think this is also a big opportunity for me. First, it will push me to speak English more. Practice makes perfect. Though my english is far away from perfect now. Second, it will improve my teaching skills significantly. I can image that this semester will be tough for me since I am taking 8 credits and audit another class and teaching. I probably do not have too much time to do my own research untill summer.

Ready for another semester with over $500 segregated fee? I hope not like this：

![Domino effect2](http://i.imgur.com/oZUdiJ1.gif)
